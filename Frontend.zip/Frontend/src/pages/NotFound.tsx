export default function NotFound(){ return <div className='text-lg'>404 Not Found</div>; }
